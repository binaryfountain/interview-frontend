package com.binaryfountain.interview.domain;

public class Aircraft {
    //TODO: Implement this class. Create new fields, classes, and/or enumerations as needed.
}
