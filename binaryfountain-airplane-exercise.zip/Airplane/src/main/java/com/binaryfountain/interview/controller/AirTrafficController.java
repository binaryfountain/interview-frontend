package com.binaryfountain.interview.controller;

import com.binaryfountain.interview.domain.Aircraft;
import com.binaryfountain.interview.service.AirTrafficControlService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class AirTrafficController {

    private final AirTrafficControlService airTrafficControlService;

    @Autowired
    public AirTrafficController(final AirTrafficControlService airTrafficControlService) {
        this.airTrafficControlService = airTrafficControlService;
    }

    @GetMapping()
    public List<Aircraft> list() {
        return airTrafficControlService.list();
    }

    @PostMapping()
    public Aircraft enqueue(@RequestBody Aircraft aircraft) {
        return airTrafficControlService.enqueue(aircraft);
    }

    @DeleteMapping()
    public Aircraft dequeue() {
        return airTrafficControlService.dequeue();
    }
}