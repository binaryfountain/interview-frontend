package com.binaryfountain.interview.service;

import com.binaryfountain.interview.domain.Aircraft;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AirTrafficControlService {

    private static final Logger logger = LoggerFactory.getLogger(AirTrafficControlService.class);

    /**
     * Add and Aircraft to the queue.
     *
     * @param aircraft Aircraft to add.
     * @return Added Aircraft.
     */
    public Aircraft enqueue(Aircraft aircraft) {
        //TODO: Implement this method.
        return null;
    }

    /**
     * Remove and Aircraft from the queue.
     *
     * @return Aircraft removed.
     */
    public Aircraft dequeue() {
        //TODO: Implement this method.
        return null;
    }

    /**
     * Return the aircraft in the queue.
     *
     * @return List of aircraft.
     */
    public List<Aircraft> list() {
        //TODO: Implement this method.
        return null;
    }
}
