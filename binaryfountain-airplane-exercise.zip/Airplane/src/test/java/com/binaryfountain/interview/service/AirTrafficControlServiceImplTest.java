package com.binaryfountain.interview.service;

import org.apache.catalina.core.ApplicationFilterConfig;
import org.junit.*;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@TestPropertySource("classpath:test.properties")
@ContextConfiguration(classes = {ApplicationFilterConfig.class})
@ComponentScan
@EnableAutoConfiguration
public class AirTrafficControlServiceImplTest {

    @Autowired
    private AirTrafficControlService airTrafficControlService;

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    @Test
    public void enqueue() {
    }

    @Test
    public void dequeue() {
    }

    @Test
    public void list() {
    }
}
